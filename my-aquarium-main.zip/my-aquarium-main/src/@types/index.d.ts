declare module "*.png";
declare module "*.gif";
declare module "*.jpeg";
declare module "*.jpg";
declare module "*.svg";
