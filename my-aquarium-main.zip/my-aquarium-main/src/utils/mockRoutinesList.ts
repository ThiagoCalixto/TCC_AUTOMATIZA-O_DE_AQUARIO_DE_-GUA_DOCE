export const routines = [
  "Luz",
  "Alimentador"
]